// Real-Time User Movement Tracking & Dynamic Activity Coaching
// Tracks if user is at rest or moving, calculates speed, distance, steps, and generates movement tasks

export type MovementState = 'AT_REST' | 'MOVING';

export interface MovementTelemetry {
  state: MovementState;
  speedMps: number;
  speedKmh: number;
  distanceCoveredMeters: number;
  stepCount: number;
  headingDegrees: number;
  timeAtRestSeconds: number;
  timeMovingSeconds: number;
  latitude: number;
  longitude: number;
  accuracy: number;
  isGpsActive: boolean;
  localityName?: string;
  activeMovementTask: string | null;
  lastStateChange: number;
}

type MovementListener = (telemetry: MovementTelemetry) => void;
type VerbalPromptTrigger = (promptText: string, reason: 'RESTING_NUDGE' | 'PACE_CONFIRMATION' | 'TASK_ASSIGNED') => void;

class MovementTrackingService {
  private watchId: number | null = null;
  private motionHandler: ((e: DeviceMotionEvent) => void) | null = null;
  private intervalTimer: any = null;
  private listeners: Set<MovementListener> = new Set();
  private verbalPromptTriggers: Set<VerbalPromptTrigger> = new Set();

  private lastLat: number | null = null;
  private lastLng: number | null = null;
  private lastTimestamp: number = Date.now();
  private stationaryTicks: number = 0;
  private movingTicks: number = 0;
  private lastVerbalNudgeTime: number = 0;

  private isExpeditionActive: boolean = false;

  private telemetry: MovementTelemetry = {
    state: 'AT_REST',
    speedMps: 0,
    speedKmh: 0,
    distanceCoveredMeters: 0,
    stepCount: 0,
    headingDegrees: 0,
    timeAtRestSeconds: 0,
    timeMovingSeconds: 0,
    latitude: 37.7749,
    longitude: -122.4194,
    accuracy: 10,
    isGpsActive: false,
    activeMovementTask: 'Put phone in pocket and take 20 paces forward to begin tracking.',
    lastStateChange: Date.now(),
  };

  constructor() {
    this.startTracking();
  }

  public getTelemetry(): MovementTelemetry {
    return { ...this.telemetry };
  }

  public subscribe(listener: MovementListener): () => void {
    this.listeners.add(listener);
    listener(this.getTelemetry());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public onVerbalPrompt(trigger: VerbalPromptTrigger): () => void {
    this.verbalPromptTriggers.add(trigger);
    return () => {
      this.verbalPromptTriggers.delete(trigger);
    };
  }

  private notify() {
    const data = this.getTelemetry();
    this.listeners.forEach((l) => l(data));
  }

  private triggerVerbalNudge(prompt: string, reason: 'RESTING_NUDGE' | 'PACE_CONFIRMATION' | 'TASK_ASSIGNED') {
    this.verbalPromptTriggers.forEach((cb) => cb(prompt, reason));
  }

  public startTracking() {
    if (typeof window === 'undefined') return;

    // 1. Geolocation Watch Position
    if ('geolocation' in navigator) {
      try {
        this.watchId = navigator.geolocation.watchPosition(
          (pos) => this.handleGpsUpdate(pos),
          (err) => {
            console.warn('Geolocation watch notice:', err.message);
            this.telemetry.isGpsActive = false;
            this.notify();
          },
          {
            enableHighAccuracy: true,
            maximumAge: 3000,
            timeout: 10000,
          }
        );
      } catch (e) {
        console.warn('Failed to start geolocation watch:', e);
      }
    }

    // 2. Accelerometer Device Motion for Step/Rest Detection
    if (typeof window !== 'undefined' && 'DeviceMotionEvent' in window) {
      let lastMag = 9.8;
      this.motionHandler = (event: DeviceMotionEvent) => {
        const acc = event.accelerationIncludingGravity;
        if (!acc || acc.x === null || acc.y === null || acc.z === null) return;
        const mag = Math.sqrt(acc.x * acc.x + acc.y * acc.y + acc.z * acc.z);
        const delta = Math.abs(mag - lastMag);
        lastMag = mag;

        // Step peak threshold
        if (delta > 2.2) {
          this.telemetry.stepCount += 1;
        }
      };

      try {
        window.addEventListener('devicemotion', this.motionHandler, { passive: true });
      } catch (_) {}
    }

    // 3. Periodic cadence timer (evaluates rest vs moving state every second)
    this.intervalTimer = setInterval(() => {
      this.tickMovementState();
    }, 1000);
  }

  private handleGpsUpdate(pos: GeolocationPosition) {
    const { latitude, longitude, speed, heading, accuracy } = pos.coords;
    const now = pos.timestamp || Date.now();

    this.telemetry.latitude = latitude;
    this.telemetry.longitude = longitude;
    this.telemetry.accuracy = accuracy;
    this.telemetry.isGpsActive = true;

    if (heading !== null && !isNaN(heading)) {
      this.telemetry.headingDegrees = Math.round(heading);
    }

    // Calculate distance and speed delta
    if (this.lastLat !== null && this.lastLng !== null) {
      const dist = this.calculateHaversineDistance(
        this.lastLat,
        this.lastLng,
        latitude,
        longitude
      );

      const timeDeltaSeconds = Math.max(0.5, (now - this.lastTimestamp) / 1000);

      // If moved reasonably (filter out GPS jitter below 1.2m if accuracy is low)
      if (dist > 1.2 && dist < 100) {
        this.telemetry.distanceCoveredMeters += Math.round(dist);
      }

      let calculatedSpeed = dist / timeDeltaSeconds;
      if (speed !== null && !isNaN(speed) && speed >= 0) {
        calculatedSpeed = speed;
      }

      // Smooth speed
      const smoothedSpeed = Math.round(calculatedSpeed * 10) / 10;
      this.telemetry.speedMps = smoothedSpeed;
      this.telemetry.speedKmh = Math.round(smoothedSpeed * 3.6 * 10) / 10;
    }

    this.lastLat = latitude;
    this.lastLng = longitude;
    this.lastTimestamp = now;

    this.notify();
  }

  public setExpeditionActive(active: boolean) {
    this.isExpeditionActive = active;
    if (active) {
      this.lastVerbalNudgeTime = Date.now();
    }
  }

  private tickMovementState() {
    const isMoving = this.telemetry.speedMps >= 0.5;
    const previousState = this.telemetry.state;

    if (isMoving) {
      this.movingTicks += 1;
      this.stationaryTicks = 0;
      this.telemetry.timeMovingSeconds += 1;
      this.telemetry.state = 'MOVING';
    } else {
      this.stationaryTicks += 1;
      this.movingTicks = 0;
      this.telemetry.timeAtRestSeconds += 1;
      this.telemetry.state = 'AT_REST';
    }

    const now = Date.now();

    // State transition events - only trigger verbal audio nudges if expedition is active
    if (this.isExpeditionActive && previousState !== this.telemetry.state) {
      this.telemetry.lastStateChange = now;

      if (this.telemetry.state === 'MOVING') {
        // Transitioned to moving!
        if (now - this.lastVerbalNudgeTime > 45000) {
          this.lastVerbalNudgeTime = now;
          this.triggerVerbalNudge(
            `Good pace Scout! You are moving at ${this.telemetry.speedMps} meters per second. Maintain heading toward your objective.`,
            'PACE_CONFIRMATION'
          );
        }
      } else {
        // Transitioned to resting
        this.telemetry.activeMovementTask = this.getRandomMovementTask();
      }
    }

    // Rest alert: Only during an active expedition, after 60s at rest, and at most once every 90s
    if (
      this.isExpeditionActive &&
      this.telemetry.state === 'AT_REST' &&
      this.stationaryTicks >= 60 &&
      now - this.lastVerbalNudgeTime > 90000
    ) {
      this.lastVerbalNudgeTime = now;
      const task = this.getRandomMovementTask();
      this.telemetry.activeMovementTask = task;
      this.triggerVerbalNudge(
        `Explorer, you are paused at rest. Whenever you are ready, ${task.toLowerCase()}`,
        'RESTING_NUDGE'
      );
    }

    this.notify();
  }

  /**
   * Generates dynamic physical movement tasks
   */
  public getRandomMovementTask(): string {
    const tasks = [
      'Take 20 paces forward to scout the ground ahead.',
      'Walk 35 meters along the path toward the nearest tree canopy.',
      'Maintain an active stride for 30 seconds to reach the next coordinates.',
      'Head slightly to your left and walk 15 paces to inspect the foliage.',
      'Pick up your walking pace for 20 strides toward the open trail.',
      'Take 25 steps forward and listen for local bird calls in the canopy.',
    ];
    return tasks[Math.floor(Math.random() * tasks.length)];
  }

  public simulateWalking() {
    this.telemetry.state = 'MOVING';
    this.telemetry.speedMps = 1.4;
    this.telemetry.speedKmh = 5.0;
    this.telemetry.stepCount += 12;
    this.telemetry.distanceCoveredMeters += 15;
    this.telemetry.lastStateChange = Date.now();
    this.notify();
  }

  public simulateRest() {
    this.telemetry.state = 'AT_REST';
    this.telemetry.speedMps = 0;
    this.telemetry.speedKmh = 0;
    this.telemetry.lastStateChange = Date.now();
    this.notify();
  }

  public assignNewMovementTask(): string {
    const newTask = this.getRandomMovementTask();
    this.telemetry.activeMovementTask = newTask;
    this.notify();
    this.triggerVerbalNudge(
      `New exploration task: ${newTask}`,
      'TASK_ASSIGNED'
    );
    return newTask;
  }

  private calculateHaversineDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371e3; // Earth radius in meters
    const phi1 = (lat1 * Math.PI) / 180;
    const phi2 = (lat2 * Math.PI) / 180;
    const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
    const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
      Math.cos(phi1) *
        Math.cos(phi2) *
        Math.sin(deltaLambda / 2) *
        Math.sin(deltaLambda / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  }

  public stopTracking() {
    if (this.watchId !== null && 'geolocation' in navigator) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    if (this.motionHandler) {
      window.removeEventListener('devicemotion', this.motionHandler);
      this.motionHandler = null;
    }
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
  }
}

export const movementTrackingService = new MovementTrackingService();
